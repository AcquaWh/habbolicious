@extends('layouts.admin')
@section('title','HabboLicious • Panel de administración')

@section('customstyles')
@endsection

@section('content')
@endsection

@section('customscripts')
@endsection