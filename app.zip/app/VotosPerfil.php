<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VotosPerfil extends Model
{
    protected $table = "hb_votos_perfil";
}
