<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VacantesRegistro extends Model
{
    protected $table = "hb_vacantes_registro";
}
