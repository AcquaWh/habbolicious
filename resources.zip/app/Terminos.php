<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Terminos extends Model
{
    protected $table = "hb_terminos";
    public $timestamps = false;
}
