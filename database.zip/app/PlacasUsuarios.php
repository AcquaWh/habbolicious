<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PlacasUsuarios extends Model
{
    protected $table = "hb_placas_usuarios";
}
