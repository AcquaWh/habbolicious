<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ComentariosEventos extends Model
{
    protected $table = "hb_comentarios_eventos";
}
