$('#summernote').summernote({
     placeholder: 'Escribe tu noticia',
     tabsize: 2,
     height: 200
});