<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Peticiones extends Model
{
    protected $table = "hb_peticiones";
}
