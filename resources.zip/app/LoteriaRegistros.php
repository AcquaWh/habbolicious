<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LoteriaRegistros extends Model
{
    protected $table = "hb_loteria_registros";
}
