<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LikeDJ extends Model
{
    protected $table = "hb_like_dj";
}
