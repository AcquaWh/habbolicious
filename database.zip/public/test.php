<html>
  <head>
    <title>Untitled</title>
  </head>
  <body>
Canción actual: <a href="https://nebula.shoutca.st/tunein/habbolicious.pls" class="cc_streaminfo" data-type="song" data-username="habbolicious">Cargando ...</a><br />
Título de la señal: <span class="cc_streaminfo" data-type="title" data-username="habbolicious"></span><br />
Tasa de bits: <span class="cc_streaminfo" data-type="bitrate" data-username="habbolicious"></span><br />
Oyentes actuales: <span class="cc_streaminfo" data-type="listeners" data-username="habbolicious"></span><br />
Oyentes simultáneos: <span class="cc_streaminfo" data-type="maxlisteners" data-username="habbolicious"></span><br />
Estado del servidor: <span class="cc_streaminfo" data-type="server" data-username="habbolicious"></span><br />
Estado AutoDJ: <span class="cc_streaminfo" data-type="autodj" data-username="habbolicious"></span><br />
Fuente conectada: <span class="cc_streaminfo" data-type="source" data-username="habbolicious"></span><br />
Tiempo de la estación: <span class="cc_streaminfo" data-type="date" data-username="habbolicious"></span> <span class="cc_streaminfo" data-type="time" data-username="habbolicious"></span><br />
Lista de reproducción en curso: <span class="cc_streaminfo" data-type="trackplaylist" data-username="habbolicious"></span><br />
Detalles del tema: <span class="cc_streaminfo" data-type="trackartist" data-username="habbolicious"></span> - <span class="cc_streaminfo" data-type="tracktitle" data-username="habbolicious"></span> - <span class="cc_streaminfo" data-type="trackalbum" data-username="habbolicious"></span><br />
Raw metadata: <span class="cc_streaminfo" data-type="rawmeta" data-username="habbolicious"></span><br />
Imagen del album:<br /><img class="cc_streaminfo" data-type="trackimageurl" data-username="habbolicious" /><br /><a href="#" class="cc_streaminfo" data-type="trackbuyurl" data-username="habbolicious">Comprar este album</a><br />
	  
	  <script language="javascript" type="text/javascript" src="https://nebula.shoutca.st/system/streaminfo.js"></script>
  </body>
</html>
