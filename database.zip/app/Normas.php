<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Normas extends Model
{
    protected $table = "hb_normas";
    public $timestamps = false;
}
