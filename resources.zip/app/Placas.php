<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Placas extends Model
{
    protected $table = "hb_placas";
}
