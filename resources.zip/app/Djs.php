<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Djs extends Model
{
    protected $table = "hb_djs";
}
