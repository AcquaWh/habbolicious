<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LikePerfil extends Model
{
    protected $table = "hb_like_perfil";
}
